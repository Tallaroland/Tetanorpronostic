import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Ce middleware tourne côté serveur pour CHAQUE requête vers /admin/*.
 * Un visiteur qui tape /admin dans son navigateur sans être ADMIN est
 * redirigé avant même que la page ne soit rendue — la protection ne
 * repose jamais sur du JavaScript côté client.
 */
export async function middleware(request: NextRequest) {
  const response = NextResponse.next({ request: { headers: request.headers } });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return request.cookies.get(name)?.value;
        },
        set(name: string, value: string, options) {
          response.cookies.set({ name, value, ...options });
        },
        remove(name: string, options) {
          response.cookies.set({ name, value: "", ...options });
        },
      },
    }
  );

  const {
    data: { user },
  } = await supabase.auth.getUser();

  const isLoginRoute = request.nextUrl.pathname === "/admin/login";

  if (!user) {
    if (isLoginRoute) return response;
    return NextResponse.redirect(new URL("/", request.url));
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", user.id)
    .single();

  const isAdmin = profile?.role === "ADMIN";

  if (isLoginRoute) {
    // Déjà connecté en tant qu'admin: pas besoin de repasser par le login.
    if (isAdmin) return NextResponse.redirect(new URL("/admin/dashboard", request.url));
    return response;
  }

  if (!isAdmin) {
    // Un utilisateur normal (ou un visiteur curieux) qui tente /admin/*
    // est renvoyé silencieusement vers l'accueil — aucun indice donné.
    return NextResponse.redirect(new URL("/", request.url));
  }

  return response;
}

export const config = {
  matcher: ["/admin/:path*"],
};

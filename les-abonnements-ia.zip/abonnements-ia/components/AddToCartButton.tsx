"use client";

import { useState } from "react";
import { useCart } from "@/contexts/CartContext";
import type { Product } from "@/lib/types";

export default function AddToCartButton({
  product,
  compact = false,
}: {
  product: Product;
  compact?: boolean;
}) {
  const { addItem, items } = useCart();
  const [added, setAdded] = useState(false);
  const alreadyInCart = items.some((i) => i.productId === product.id);

  function handleClick() {
    addItem({
      productId: product.id,
      name: product.name,
      slug: product.slug,
      price: product.price,
      image_url: product.image_url,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  }

  return (
    <button
      onClick={handleClick}
      disabled={alreadyInCart}
      className={
        compact
          ? "flex-1 rounded-lg bg-gold py-2.5 text-sm font-semibold text-ink transition-opacity hover:opacity-90 disabled:opacity-50"
          : "w-full rounded-card bg-gold py-3.5 text-sm font-semibold text-ink transition-opacity hover:opacity-90 disabled:opacity-50"
      }
    >
      {alreadyInCart ? "Dans le panier" : added ? "Ajouté ✓" : "Acheter"}
    </button>
  );
}

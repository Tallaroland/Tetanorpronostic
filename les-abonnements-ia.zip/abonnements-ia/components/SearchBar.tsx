"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function SearchBar({ defaultValue }: { defaultValue?: string }) {
  const router = useRouter();
  const [value, setValue] = useState(defaultValue ?? "");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const params = new URLSearchParams();
    if (value.trim()) params.set("q", value.trim());
    router.push(`/produits${params.toString() ? `?${params}` : ""}`);
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="search"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Rechercher un produit, une catégorie…"
        className="w-full rounded-card border border-line bg-surface px-4 py-3 text-sm text-paper placeholder:text-muted focus:border-teal"
      />
      <button
        type="submit"
        className="shrink-0 rounded-card border border-line px-5 text-sm text-paper hover:border-teal"
      >
        Rechercher
      </button>
    </form>
  );
}

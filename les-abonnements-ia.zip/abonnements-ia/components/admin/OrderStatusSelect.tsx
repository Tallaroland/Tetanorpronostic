"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function OrderStatusSelect({
  orderId,
  status,
  labels,
}: {
  orderId: string;
  status: string;
  labels: Record<string, string>;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function handleChange(e: React.ChangeEvent<HTMLSelectElement>) {
    setBusy(true);
    await fetch(`/api/admin/orders/${orderId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: e.target.value }),
    });
    setBusy(false);
    router.refresh();
  }

  return (
    <select
      value={status}
      disabled={busy}
      onChange={handleChange}
      className="rounded-full border border-line bg-surface px-3 py-1 text-xs text-paper disabled:opacity-50"
    >
      {Object.entries(labels).map(([value, label]) => (
        <option key={value} value={value}>
          {label}
        </option>
      ))}
    </select>
  );
}

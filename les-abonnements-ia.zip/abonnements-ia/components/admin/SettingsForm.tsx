"use client";

import { useState } from "react";

type StoreSettings = { name: string; currency: string; contact_email: string };

export default function SettingsForm({ initial }: { initial: StoreSettings }) {
  const [form, setForm] = useState(initial);
  const [saved, setSaved] = useState(false);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    await fetch("/api/admin/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setBusy(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const inputClass =
    "w-full rounded-card border border-line bg-surface px-4 py-2.5 text-sm text-paper focus:border-teal";

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="mb-1.5 block text-sm text-muted">Nom de la boutique</label>
        <input
          className={inputClass}
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
      </div>
      <div>
        <label className="mb-1.5 block text-sm text-muted">Devise</label>
        <input
          className={inputClass}
          value={form.currency}
          onChange={(e) => setForm({ ...form, currency: e.target.value })}
        />
      </div>
      <div>
        <label className="mb-1.5 block text-sm text-muted">E-mail de contact</label>
        <input
          type="email"
          className={inputClass}
          value={form.contact_email}
          onChange={(e) => setForm({ ...form, contact_email: e.target.value })}
        />
      </div>
      <button
        type="submit"
        disabled={busy}
        className="rounded-card bg-gold px-5 py-2.5 text-sm font-semibold text-ink disabled:opacity-50"
      >
        {saved ? "Enregistré ✓" : busy ? "Enregistrement…" : "Enregistrer"}
      </button>
    </form>
  );
}

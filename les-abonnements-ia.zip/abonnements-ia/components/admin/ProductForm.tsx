"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { Category, Product } from "@/lib/types";

type Props = {
  categories: Category[];
  product?: Product;
};

export default function ProductForm({ categories, product }: Props) {
  const router = useRouter();
  const [saving, setSaving] = useState<"draft" | "publish" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [form, setForm] = useState({
    name: product?.name ?? "",
    short_description: product?.short_description ?? "",
    description: product?.description ?? "",
    price: product?.price ?? 0,
    old_price: product?.old_price ?? undefined,
    category_id: product?.category_id ?? "",
    image_url: product?.image_url ?? "",
    galleryText: (product?.gallery_urls ?? []).join("\n"),
    benefitsText: (product?.benefits ?? []).join("\n"),
    featuresText: (product?.features ?? []).map((f) => `${f.label}: ${f.value}`).join("\n"),
    product_type: product?.product_type ?? "DOWNLOAD",
    delivery_url: product?.delivery_url ?? "",
  });

  function update<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave(status: "DRAFT" | "PUBLISHED") {
    setSaving(status === "DRAFT" ? "draft" : "publish");
    setError(null);

    const payload = {
      name: form.name,
      short_description: form.short_description || undefined,
      description: form.description || undefined,
      price: Number(form.price),
      old_price: form.old_price ? Number(form.old_price) : null,
      category_id: form.category_id || null,
      image_url: form.image_url || null,
      gallery_urls: form.galleryText.split("\n").map((s) => s.trim()).filter(Boolean),
      benefits: form.benefitsText.split("\n").map((s) => s.trim()).filter(Boolean),
      features: form.featuresText
        .split("\n")
        .map((line) => line.trim())
        .filter(Boolean)
        .map((line) => {
          const [label, ...rest] = line.split(":");
          return { label: label.trim(), value: rest.join(":").trim() };
        }),
      product_type: form.product_type,
      delivery_url: form.delivery_url || null,
      status,
    };

    try {
      const res = await fetch(
        product ? `/api/admin/products/${product.id}` : "/api/admin/products",
        {
          method: product ? "PATCH" : "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        }
      );
      if (!res.ok) {
        const data = await res.json();
        throw new Error(typeof data.error === "string" ? data.error : "Erreur de validation.");
      }
      router.push("/admin/products");
      router.refresh();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setSaving(null);
    }
  }

  const inputClass =
    "w-full rounded-card border border-line bg-surface px-4 py-2.5 text-sm text-paper focus:border-teal";
  const labelClass = "mb-1.5 block text-sm text-muted";

  return (
    <div className="max-w-3xl space-y-6">
      <div>
        <label className={labelClass}>Nom du produit</label>
        <input className={inputClass} value={form.name} onChange={(e) => update("name", e.target.value)} />
      </div>

      <div>
        <label className={labelClass}>Description courte</label>
        <input
          className={inputClass}
          value={form.short_description}
          onChange={(e) => update("short_description", e.target.value)}
        />
      </div>

      <div>
        <label className={labelClass}>Description complète</label>
        <textarea
          rows={5}
          className={inputClass}
          value={form.description}
          onChange={(e) => update("description", e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>Prix (FCFA)</label>
          <input
            type="number"
            className={inputClass}
            value={form.price}
            onChange={(e) => update("price", Number(e.target.value) as any)}
          />
        </div>
        <div>
          <label className={labelClass}>Ancien prix (promotion, optionnel)</label>
          <input
            type="number"
            className={inputClass}
            value={form.old_price ?? ""}
            onChange={(e) => update("old_price", (e.target.value ? Number(e.target.value) : undefined) as any)}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className={labelClass}>Catégorie</label>
          <select
            className={inputClass}
            value={form.category_id}
            onChange={(e) => update("category_id", e.target.value)}
          >
            <option value="">— Aucune —</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className={labelClass}>Type de produit</label>
          <select
            className={inputClass}
            value={form.product_type}
            onChange={(e) => update("product_type", e.target.value as any)}
          >
            <option value="DOWNLOAD">Téléchargement</option>
            <option value="ACCESS">Accès</option>
            <option value="SUBSCRIPTION">Abonnement</option>
            <option value="OTHER">Autre</option>
          </select>
        </div>
      </div>

      <div>
        <label className={labelClass}>Image principale (URL)</label>
        <input className={inputClass} value={form.image_url} onChange={(e) => update("image_url", e.target.value)} />
      </div>

      <div>
        <label className={labelClass}>Images supplémentaires (une URL par ligne)</label>
        <textarea
          rows={3}
          className={inputClass}
          value={form.galleryText}
          onChange={(e) => update("galleryText", e.target.value)}
        />
      </div>

      <div>
        <label className={labelClass}>
          Fichier ou lien de livraison (privé — jamais affiché publiquement)
        </label>
        <input
          className={inputClass}
          value={form.delivery_url}
          onChange={(e) => update("delivery_url", e.target.value)}
          placeholder="Chemin vers le fichier dans le stockage privé Supabase"
        />
      </div>

      <div>
        <label className={labelClass}>Avantages (un par ligne)</label>
        <textarea
          rows={3}
          className={inputClass}
          value={form.benefitsText}
          onChange={(e) => update("benefitsText", e.target.value)}
        />
      </div>

      <div>
        <label className={labelClass}>Caractéristiques (format "Label: Valeur", une par ligne)</label>
        <textarea
          rows={3}
          className={inputClass}
          value={form.featuresText}
          onChange={(e) => update("featuresText", e.target.value)}
        />
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      <div className="flex gap-3">
        <button
          onClick={() => handleSave("DRAFT")}
          disabled={!!saving}
          className="rounded-card border border-line px-5 py-2.5 text-sm text-paper disabled:opacity-50"
        >
          {saving === "draft" ? "Enregistrement…" : "Enregistrer comme brouillon"}
        </button>
        <button
          onClick={() => handleSave("PUBLISHED")}
          disabled={!!saving}
          className="rounded-card bg-gold px-5 py-2.5 text-sm font-semibold text-ink disabled:opacity-50"
        >
          {saving === "publish" ? "Publication…" : "Publier le produit"}
        </button>
      </div>
    </div>
  );
}

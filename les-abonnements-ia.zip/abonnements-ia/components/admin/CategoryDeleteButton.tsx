"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function CategoryDeleteButton({ categoryId }: { categoryId: string }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function handleDelete() {
    if (!confirm("Supprimer cette catégorie ?")) return;
    setBusy(true);
    await fetch(`/api/admin/categories/${categoryId}`, { method: "DELETE" });
    setBusy(false);
    router.refresh();
  }

  return (
    <button disabled={busy} onClick={handleDelete} className="text-xs text-red-400 hover:underline disabled:opacity-50">
      Supprimer
    </button>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function CategoryForm() {
  const router = useRouter();
  const [name, setName] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    await fetch("/api/admin/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim() }),
    });
    setName("");
    setBusy(false);
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Nom de la catégorie"
        className="w-full rounded-card border border-line bg-surface px-4 py-2.5 text-sm focus:border-teal"
      />
      <button
        type="submit"
        disabled={busy}
        className="shrink-0 rounded-card bg-gold px-5 text-sm font-semibold text-ink disabled:opacity-50"
      >
        Ajouter
      </button>
    </form>
  );
}

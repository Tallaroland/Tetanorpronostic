"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function ProductRowActions({
  productId,
  status,
}: {
  productId: string;
  status: "DRAFT" | "PUBLISHED";
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function togglePublish() {
    setBusy(true);
    await fetch(`/api/admin/products/${productId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: status === "PUBLISHED" ? "DRAFT" : "PUBLISHED" }),
    });
    setBusy(false);
    router.refresh();
  }

  async function handleDelete() {
    if (!confirm("Êtes-vous sûr de vouloir supprimer ce produit ? Cette action est irréversible.")) {
      return;
    }
    setBusy(true);
    await fetch(`/api/admin/products/${productId}`, { method: "DELETE" });
    setBusy(false);
    router.refresh();
  }

  return (
    <div className="flex justify-end gap-3 text-xs">
      <Link href={`/admin/products/${productId}/edit`} className="text-teal hover:underline">
        Modifier
      </Link>
      <button disabled={busy} onClick={togglePublish} className="text-gold hover:underline disabled:opacity-50">
        {status === "PUBLISHED" ? "Dépublier" : "Publier"}
      </button>
      <button disabled={busy} onClick={handleDelete} className="text-red-400 hover:underline disabled:opacity-50">
        Supprimer
      </button>
    </div>
  );
}

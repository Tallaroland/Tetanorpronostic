"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

const LINKS = [
  { href: "/admin/dashboard", label: "Dashboard" },
  { href: "/admin/products", label: "Produits" },
  { href: "/admin/orders", label: "Commandes" },
  { href: "/admin/customers", label: "Clients" },
  { href: "/admin/categories", label: "Catégories" },
  { href: "/admin/settings", label: "Paramètres" },
];

export default function AdminSidebar({ adminName }: { adminName: string }) {
  const pathname = usePathname();
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <>
      {/* Mobile: barre horizontale scrollable en haut */}
      <nav className="flex gap-2 overflow-x-auto border-b border-line/60 bg-surface px-4 py-3 md:hidden">
        {LINKS.map((link) => {
          const active = pathname.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className={`shrink-0 rounded-full border px-3 py-1.5 text-xs ${
                active ? "border-gold text-gold" : "border-line text-muted"
              }`}
            >
              {link.label}
            </Link>
          );
        })}
        <button onClick={handleLogout} className="shrink-0 rounded-full border border-line px-3 py-1.5 text-xs text-muted">
          Déconnexion
        </button>
      </nav>

      {/* Desktop: sidebar fixe */}
      <aside className="hidden w-60 shrink-0 border-r border-line/60 bg-surface md:block">
        <div className="border-b border-line/60 px-6 py-6">
          <p className="text-sm text-muted">Connecté en tant que</p>
          <p className="truncate text-sm text-paper">{adminName}</p>
        </div>
        <nav className="flex flex-col gap-1 p-4">
          {LINKS.map((link) => {
            const active = pathname.startsWith(link.href);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-lg px-3 py-2.5 text-sm transition-colors ${
                  active ? "bg-surface2 text-gold" : "text-muted hover:text-paper"
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-4">
          <button
            onClick={handleLogout}
            className="w-full rounded-lg border border-line px-3 py-2.5 text-left text-sm text-muted hover:text-paper"
          >
            Déconnexion
          </button>
        </div>
      </aside>
    </>
  );
}

import Link from "next/link";

export default function SiteFooter() {
  return (
    <footer className="border-t border-line/60 py-10">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 text-sm text-muted md:flex-row md:items-center md:justify-between">
        <p>© {new Date().getFullYear()} Les Abonnements IA. Tous droits réservés.</p>
        <div className="flex gap-6">
          <Link href="/produits" className="hover:text-paper">Produits</Link>
          <Link href="/categories" className="hover:text-paper">Catégories</Link>
          <Link href="/contact" className="hover:text-paper">Contact</Link>
        </div>
      </div>
    </footer>
  );
}

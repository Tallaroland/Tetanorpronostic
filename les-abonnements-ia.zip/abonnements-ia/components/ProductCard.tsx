import Link from "next/link";
import Image from "next/image";
import type { Product } from "@/lib/types";
import AddToCartButton from "@/components/AddToCartButton";

const NEW_WINDOW_DAYS = 14;

export default function ProductCard({ product }: { product: Product }) {
  const isNew =
    Date.now() - new Date(product.created_at).getTime() < NEW_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  const hasPromo = !!product.old_price && product.old_price > product.price;
  const discount = hasPromo
    ? Math.round((1 - product.price / (product.old_price as number)) * 100)
    : 0;

  return (
    <div className="group flex flex-col overflow-hidden rounded-card border border-line bg-surface transition-colors hover:border-teal/60">
      <Link href={`/produits/${product.slug}`} className="relative block aspect-[4/3] bg-surface2">
        {product.image_url ? (
          <Image
            src={product.image_url}
            alt={product.name}
            fill
            sizes="(max-width: 768px) 100vw, 33vw"
            className="object-cover"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-muted">Aperçu</div>
        )}

        <div className="absolute left-3 top-3 flex gap-2">
          {isNew && (
            <span className="rounded-full bg-teal px-2.5 py-1 text-[11px] font-semibold text-ink">
              Nouveau
            </span>
          )}
          {hasPromo && (
            <span className="rounded-full bg-gold px-2.5 py-1 text-[11px] font-semibold text-ink">
              -{discount}%
            </span>
          )}
        </div>
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <Link href={`/produits/${product.slug}`}>
          <h3 className="line-clamp-1 font-display text-base font-medium text-paper">
            {product.name}
          </h3>
        </Link>
        {product.short_description && (
          <p className="mt-1.5 line-clamp-2 text-sm text-muted">{product.short_description}</p>
        )}

        <div className="mt-4 flex items-baseline gap-2">
          <span className="text-lg font-semibold text-paper">
            {product.price.toLocaleString("fr-FR")} FCFA
          </span>
          {hasPromo && (
            <span className="text-sm text-muted line-through">
              {product.old_price?.toLocaleString("fr-FR")} FCFA
            </span>
          )}
        </div>

        <div className="mt-4 flex gap-2">
          <Link
            href={`/produits/${product.slug}`}
            className="flex-1 rounded-lg border border-line py-2.5 text-center text-sm text-paper transition-colors hover:border-gold"
          >
            Voir le produit
          </Link>
          <AddToCartButton product={product} compact />
        </div>
      </div>
    </div>
  );
}

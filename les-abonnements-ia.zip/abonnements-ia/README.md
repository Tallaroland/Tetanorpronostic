# Les Abonnements IA

Boutique de produits digitaux (formations, e-books, templates, abonnements IA…)
avec back-office administrateur sécurisé, pensée pour le marché camerounais et
africain. Next.js 14 (App Router) + Supabase (Postgres, Auth, Storage).

Ceci est une **vraie application fonctionnelle**, pas une maquette : frontend,
backend (routes API), base de données, authentification avec rôles, CRUD
produits complet, panier, commande, et architecture de paiement prête à être
connectée à un agrégateur Mobile Money.

---

## 1. Installation locale

```bash
npm install
cp .env.example .env.local
```

Remplissez `.env.local` avec vos propres valeurs (voir étape 2).

```bash
npm run dev
```

Le site est disponible sur http://localhost:3000.

---

## 2. Configuration Supabase (obligatoire)

1. Créez un projet sur [supabase.com](https://supabase.com).
2. Dans **Project Settings > API**, copiez :
   - `Project URL` → `NEXT_PUBLIC_SUPABASE_URL`
   - `anon public` key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `service_role` key → `SUPABASE_SERVICE_ROLE_KEY` (⚠️ secrète, ne jamais
     la mettre dans du code exposé au navigateur — elle n'est utilisée que
     dans les routes `app/api/**`)
3. Ouvrez **SQL Editor** et exécutez le contenu de `supabase/schema.sql`.
   Cela crée toutes les tables, les policies de sécurité (RLS), et le
   déclencheur qui crée automatiquement un profil `USER` à chaque inscription.

### Créer votre premier compte administrateur

Aucune inscription publique ne donne le rôle ADMIN — c'est volontaire.

1. Sur votre site (ou via Supabase Auth > Users > "Add user"), créez un
   compte avec votre e-mail et un mot de passe.
2. Dans **SQL Editor**, passez ce compte en administrateur :

```sql
update profiles set role = 'ADMIN' where email = 'votre@email.com';
```

3. Connectez-vous ensuite sur `/admin/login` avec ce compte.

---

## 3. Sécurité du back-office — ce qui est déjà en place

- **Route non devinable par défaut** : le menu public ne contient aucun lien
  vers `/admin`. Vous pouvez renommer cette route (ex. `/gestion-x7k2`) en
  renommant le dossier `app/admin` — pensez à adapter le `matcher` dans
  `middleware.ts`.
- **Protection serveur, pas seulement JavaScript** : `middleware.ts`
  intercepte toute requête vers `/admin/*` et vérifie le rôle en base avant
  même de rendre la page. Un utilisateur non-admin est redirigé vers `/`.
- **Aucun secret côté frontend** : la clé `service_role` n'est importée que
  dans des fichiers marqués `import "server-only"`, ce qui fait échouer le
  build si elle était accidentellement utilisée dans un composant client.
- **RLS en base** : même si une route API avait un bug, les policies
  Postgres empêchent un utilisateur anonyme ou USER de lire les produits en
  brouillon, de modifier son propre rôle, ou d'écrire dans `orders`.

---

## 4. Paiement Mobile Money — à connecter

L'architecture est prête (table `payments`, statuts de commande) mais
**aucun agrégateur n'est branché** : cela nécessite un compte marchand réel
(CinetPay, NotchPay, PawaPay, etc.) que je n'ai pas.

Pour l'intégrer, dans `app/api/checkout/route.ts` :

1. Après la création de la commande, appelez l'API du prestataire avec le
   montant, le numéro Mobile Money et une URL de retour.
2. Stockez la référence retournée dans `payments.provider_reference`.
3. Créez une route `app/api/webhooks/payment/route.ts` qui reçoit la
   confirmation du prestataire, passe `orders.status` à `PAID`, puis génère
   les entrées `digital_deliveries` pour chaque `order_item` et envoie
   l'accès au client par e-mail.

---

## 5. Stockage des fichiers digitaux

Créez un bucket **privé** dans Supabase Storage (Storage > New bucket,
décochez "Public"). Uploadez vos fichiers depuis le formulaire admin (champ
"Fichier ou lien de livraison") en y stockant le chemin interne, jamais une
URL publique directe. La génération de liens signés à durée limitée se fait
via `supabase.storage.from('bucket').createSignedUrl(path, expiresIn)`, à
appeler uniquement après vérification du paiement.

---

## 6. Déploiement sur Vercel

1. Poussez ce projet sur GitHub.
2. Importez le repo sur [vercel.com](https://vercel.com).
3. Ajoutez les mêmes variables que `.env.local` dans Vercel > Settings >
   Environment Variables.
4. Déployez.

---

## 7. Structure du projet

```
app/(public)/       pages publiques (accueil, produits, panier, checkout…)
app/admin/           back-office (protégé par middleware.ts)
app/api/admin/       routes API réservées aux ADMIN (requireAdmin() partout)
app/api/checkout/    création de commande (accessible sans compte)
lib/supabase/        3 clients Supabase (browser / server / admin)
lib/auth.ts          vérification du rôle côté serveur
supabase/schema.sql  schéma complet + RLS + trigger
```

## 8. Ce qui reste à faire pour la mise en production

- Brancher un vrai prestataire de paiement Mobile Money (voir section 4)
- Générer et envoyer les liens de téléchargement sécurisés après paiement
- Ajouter l'upload d'image direct dans le formulaire produit (actuellement :
  coller une URL — vous pouvez utiliser Supabase Storage + un composant
  d'upload)
- Emails transactionnels (confirmation de commande, accès au produit) via un
  service comme Resend ou Postmark
- Tester le parcours complet en environnement Supabase réel avant mise en ligne

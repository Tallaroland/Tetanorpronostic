import { NextResponse } from "next/server";
import { z } from "zod";
import { getAdminClient } from "@/lib/supabase/admin";

/**
 * Cette route est appelée par les visiteurs non connectés (pas de compte
 * requis pour acheter). Elle utilise le client "admin" (service_role)
 * UNIQUEMENT côté serveur pour créer la commande, car aucune policy RLS
 * n'autorise l'écriture anonyme sur "orders" — c'est cette route, et elle
 * seule, qui fait le pont, après avoir validé et recalculé les prix.
 */

const bodySchema = z.object({
  customer: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    phone: z.string().min(6),
  }),
  items: z
    .array(
      z.object({
        productId: z.string().uuid(),
        quantity: z.number().int().min(1).max(10),
      })
    )
    .min(1),
});

export async function POST(request: Request) {
  const parsed = bodySchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: "Données invalides." }, { status: 400 });
  }
  const { customer, items } = parsed.data;

  const supabase = getAdminClient();

  // Recalcule les prix depuis la base — ne jamais faire confiance au prix
  // envoyé par le navigateur.
  const { data: products, error: productsError } = await supabase
    .from("products")
    .select("id, name, price, status")
    .in(
      "id",
      items.map((i) => i.productId)
    );

  if (productsError || !products || products.length !== items.length) {
    return NextResponse.json({ error: "Un ou plusieurs produits sont introuvables." }, { status: 400 });
  }
  if (products.some((p) => p.status !== "PUBLISHED")) {
    return NextResponse.json({ error: "Un produit n'est plus disponible à la vente." }, { status: 400 });
  }

  const total = items.reduce((sum, item) => {
    const product = products.find((p) => p.id === item.productId)!;
    return sum + product.price * item.quantity;
  }, 0);

  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert({
      customer_email: customer.email,
      customer_name: customer.name,
      total,
      status: "PENDING",
    })
    .select("id")
    .single();

  if (orderError || !order) {
    return NextResponse.json({ error: "Impossible de créer la commande." }, { status: 500 });
  }

  const orderItems = items.map((item) => {
    const product = products.find((p) => p.id === item.productId)!;
    return {
      order_id: order.id,
      product_id: product.id,
      product_name: product.name,
      unit_price: product.price,
      quantity: item.quantity,
    };
  });

  await supabase.from("order_items").insert(orderItems);

  // --- Intégration paiement Mobile Money ---
  // Ici, appeler l'agrégateur choisi (CinetPay, Notchpay, PawaPay, etc.) avec
  // process.env.PAYMENT_API_KEY côté serveur, transmettre customer.phone et
  // `total`, puis stocker la référence retournée dans `payments` et rediriger
  // le client vers paymentUrl. Le webhook du prestataire, reçu sur une route
  // dédiée (ex: /api/webhooks/payment), doit ensuite passer orders.status à
  // 'PAID' et déclencher la génération des digital_deliveries.
  await supabase.from("payments").insert({
    order_id: order.id,
    provider: process.env.PAYMENT_PROVIDER || "unconfigured",
    amount: total,
    status: "PENDING",
  });

  return NextResponse.json({ orderId: order.id, paymentUrl: null });
}

import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";

const schema = z.object({
  status: z.enum(["PENDING", "PAID", "FAILED", "CANCELLED"]),
});

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const parsed = schema.safeParse(await request.json());
  if (!parsed.success) return NextResponse.json({ error: "Statut invalide." }, { status: 400 });

  const supabase = getAdminClient();
  const { error } = await supabase
    .from("orders")
    .update({ status: parsed.data.status, updated_at: new Date().toISOString() })
    .eq("id", params.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  // Quand une commande passe à PAID: c'est ici (ou dans le webhook du prestataire
  // de paiement) qu'il faut générer les digital_deliveries pour chaque order_item
  // et notifier le client par e-mail avec son lien d'accès.

  return NextResponse.json({ ok: true });
}

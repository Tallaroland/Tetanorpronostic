import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";

const productSchema = z.object({
  name: z.string().min(2),
  short_description: z.string().optional(),
  description: z.string().optional(),
  price: z.number().int().nonnegative(),
  old_price: z.number().int().nonnegative().nullable().optional(),
  category_id: z.string().uuid().nullable().optional(),
  image_url: z.string().url().nullable().optional(),
  gallery_urls: z.array(z.string().url()).optional(),
  benefits: z.array(z.string()).optional(),
  features: z.array(z.object({ label: z.string(), value: z.string() })).optional(),
  product_type: z.enum(["DOWNLOAD", "ACCESS", "SUBSCRIPTION", "OTHER"]),
  delivery_url: z.string().nullable().optional(),
  status: z.enum(["DRAFT", "PUBLISHED"]).default("DRAFT"),
  seo_title: z.string().optional(),
  seo_description: z.string().optional(),
});

function slugify(input: string) {
  return input
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

// POST /api/admin/products — création d'un produit (garde ADMIN systématique)
export async function POST(request: Request) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const parsed = productSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const supabase = getAdminClient();
  const slug = `${slugify(parsed.data.name)}-${Math.random().toString(36).slice(2, 7)}`;

  const { data, error } = await supabase
    .from("products")
    .insert({ ...parsed.data, slug })
    .select("id, slug")
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json({ id: data.id, slug: data.slug }, { status: 201 });
}

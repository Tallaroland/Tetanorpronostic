import { NextResponse } from "next/server";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";

const updateSchema = z.object({
  name: z.string().min(2).optional(),
  short_description: z.string().optional(),
  description: z.string().optional(),
  price: z.number().int().nonnegative().optional(),
  old_price: z.number().int().nonnegative().nullable().optional(),
  category_id: z.string().uuid().nullable().optional(),
  image_url: z.string().url().nullable().optional(),
  gallery_urls: z.array(z.string().url()).optional(),
  benefits: z.array(z.string()).optional(),
  features: z.array(z.object({ label: z.string(), value: z.string() })).optional(),
  product_type: z.enum(["DOWNLOAD", "ACCESS", "SUBSCRIPTION", "OTHER"]).optional(),
  delivery_url: z.string().nullable().optional(),
  status: z.enum(["DRAFT", "PUBLISHED"]).optional(),
  seo_title: z.string().optional(),
  seo_description: z.string().optional(),
});

export async function GET(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const supabase = getAdminClient();
  const { data, error } = await supabase.from("products").select("*").eq("id", params.id).single();
  if (error || !data) return NextResponse.json({ error: "Produit introuvable." }, { status: 404 });
  return NextResponse.json(data);
}

export async function PATCH(request: Request, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const parsed = updateSchema.safeParse(await request.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const supabase = getAdminClient();
  const { error } = await supabase
    .from("products")
    .update({ ...parsed.data, updated_at: new Date().toISOString() })
    .eq("id", params.id);

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}

export async function DELETE(_request: Request, { params }: { params: { id: string } }) {
  try {
    await requireAdmin();
  } catch {
    return NextResponse.json({ error: "Accès refusé." }, { status: 403 });
  }

  const supabase = getAdminClient();
  const { error } = await supabase.from("products").delete().eq("id", params.id);
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ ok: true });
}

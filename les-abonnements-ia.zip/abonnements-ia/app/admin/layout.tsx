import { getCurrentProfile } from "@/lib/auth";
import AdminSidebar from "@/components/admin/AdminSidebar";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const profile = await getCurrentProfile();

  // Le middleware a déjà bloqué les non-admins avant d'arriver ici.
  // La page /admin/login n'utilise pas ce layout (voir app/admin/login/page.tsx
  // qui est en dehors de toute vérification bloquante côté rendu).
  if (!profile) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen bg-ink text-paper">
      <AdminSidebar adminName={profile.full_name || profile.email} />
      <main className="flex-1 px-6 py-8 md:px-10">{children}</main>
    </div>
  );
}

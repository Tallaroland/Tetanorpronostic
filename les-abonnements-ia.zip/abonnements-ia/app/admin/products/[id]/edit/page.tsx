import { notFound } from "next/navigation";
import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";
import ProductForm from "@/components/admin/ProductForm";
import type { Product } from "@/lib/types";

export default async function EditProductPage({ params }: { params: { id: string } }) {
  await requireAdmin();
  const supabase = getAdminClient();

  const [{ data: product }, { data: categories }] = await Promise.all([
    supabase.from("products").select("*").eq("id", params.id).single(),
    supabase.from("categories").select("*").order("name"),
  ]);

  if (!product) notFound();

  return (
    <div>
      <h1 className="text-2xl font-medium">Modifier le produit</h1>
      <div className="mt-8">
        <ProductForm categories={categories ?? []} product={product as Product} />
      </div>
    </div>
  );
}

import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";
import ProductForm from "@/components/admin/ProductForm";

export default async function NewProductPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data: categories } = await supabase.from("categories").select("*").order("name");

  return (
    <div>
      <h1 className="text-2xl font-medium">Ajouter un produit</h1>
      <div className="mt-8">
        <ProductForm categories={categories ?? []} />
      </div>
    </div>
  );
}

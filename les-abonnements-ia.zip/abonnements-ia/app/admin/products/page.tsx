import Link from "next/link";
import { getAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/lib/auth";
import ProductRowActions from "@/components/admin/ProductRowActions";

export default async function AdminProductsPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data: products } = await supabase
    .from("products")
    .select("id, name, price, status, product_type, created_at")
    .order("created_at", { ascending: false });

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-medium">Produits</h1>
        <Link
          href="/admin/products/new"
          className="rounded-card bg-gold px-5 py-2.5 text-sm font-semibold text-ink"
        >
          Ajouter un produit
        </Link>
      </div>

      <div className="mt-8 overflow-x-auto rounded-card border border-line">
        <table className="w-full text-left text-sm">
          <thead className="bg-surface text-muted">
            <tr>
              <th className="px-4 py-3">Nom</th>
              <th className="px-4 py-3">Prix</th>
              <th className="px-4 py-3">Statut</th>
              <th className="px-4 py-3">Type</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line/60">
            {(products ?? []).map((p) => (
              <tr key={p.id}>
                <td className="px-4 py-3">{p.name}</td>
                <td className="px-4 py-3">{p.price.toLocaleString("fr-FR")} FCFA</td>
                <td className="px-4 py-3">
                  <span
                    className={`rounded-full px-2.5 py-1 text-xs ${
                      p.status === "PUBLISHED" ? "bg-teal/20 text-teal" : "bg-surface2 text-muted"
                    }`}
                  >
                    {p.status === "PUBLISHED" ? "Publié" : "Brouillon"}
                  </span>
                </td>
                <td className="px-4 py-3 text-muted">{p.product_type}</td>
                <td className="px-4 py-3">
                  <ProductRowActions productId={p.id} status={p.status} />
                </td>
              </tr>
            ))}
            {(products ?? []).length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  Aucun produit. Ajoutez-en un pour commencer.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

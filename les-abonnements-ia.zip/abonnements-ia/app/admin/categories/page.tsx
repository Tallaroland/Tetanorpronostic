import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";
import CategoryForm from "@/components/admin/CategoryForm";
import CategoryDeleteButton from "@/components/admin/CategoryDeleteButton";

export default async function AdminCategoriesPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data: categories } = await supabase.from("categories").select("*").order("name");

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-medium">Catégories</h1>

      <div className="mt-8">
        <CategoryForm />
      </div>

      <ul className="mt-8 divide-y divide-line/60 rounded-card border border-line">
        {(categories ?? []).map((c) => (
          <li key={c.id} className="flex items-center justify-between px-4 py-3">
            <span>{c.name}</span>
            <CategoryDeleteButton categoryId={c.id} />
          </li>
        ))}
        {(categories ?? []).length === 0 && (
          <li className="px-4 py-8 text-center text-muted">Aucune catégorie.</li>
        )}
      </ul>
    </div>
  );
}

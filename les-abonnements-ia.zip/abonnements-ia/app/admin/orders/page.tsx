import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";
import OrderStatusSelect from "@/components/admin/OrderStatusSelect";

const STATUS_LABEL: Record<string, string> = {
  PENDING: "En attente",
  PAID: "Payée",
  FAILED: "Échouée",
  CANCELLED: "Annulée",
};

export default async function AdminOrdersPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data: orders } = await supabase
    .from("orders")
    .select("id, customer_name, customer_email, total, status, created_at")
    .order("created_at", { ascending: false });

  return (
    <div>
      <h1 className="text-2xl font-medium">Commandes</h1>

      <div className="mt-8 overflow-x-auto rounded-card border border-line">
        <table className="w-full text-left text-sm">
          <thead className="bg-surface text-muted">
            <tr>
              <th className="px-4 py-3">Client</th>
              <th className="px-4 py-3">E-mail</th>
              <th className="px-4 py-3">Total</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Statut</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line/60">
            {(orders ?? []).map((o) => (
              <tr key={o.id}>
                <td className="px-4 py-3">{o.customer_name}</td>
                <td className="px-4 py-3 text-muted">{o.customer_email}</td>
                <td className="px-4 py-3">{o.total.toLocaleString("fr-FR")} FCFA</td>
                <td className="px-4 py-3 text-muted">
                  {new Date(o.created_at).toLocaleDateString("fr-FR")}
                </td>
                <td className="px-4 py-3">
                  <OrderStatusSelect orderId={o.id} status={o.status} labels={STATUS_LABEL} />
                </td>
              </tr>
            ))}
            {(orders ?? []).length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  Aucune commande pour le moment.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

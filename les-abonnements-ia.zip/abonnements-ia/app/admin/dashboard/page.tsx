import { getAdminClient } from "@/lib/supabase/admin";
import { requireAdmin } from "@/lib/auth";

export default async function AdminDashboardPage() {
  await requireAdmin();
  const supabase = getAdminClient();

  const [
    { count: productsCount },
    { count: publishedCount },
    { count: draftCount },
    { count: ordersCount },
    { data: allOrders },
    { data: paidOrders },
  ] = await Promise.all([
    supabase.from("products").select("*", { count: "exact", head: true }),
    supabase.from("products").select("*", { count: "exact", head: true }).eq("status", "PUBLISHED"),
    supabase.from("products").select("*", { count: "exact", head: true }).eq("status", "DRAFT"),
    supabase.from("orders").select("*", { count: "exact", head: true }),
    supabase.from("orders").select("customer_email"),
    supabase.from("orders").select("total").eq("status", "PAID"),
  ]);

  const revenue = (paidOrders ?? []).reduce((sum, o: any) => sum + (o.total || 0), 0);
  const uniqueCustomers = new Set((allOrders ?? []).map((o: any) => o.customer_email)).size;

  const stats = [
    { label: "Chiffre d'affaires", value: `${revenue.toLocaleString("fr-FR")} FCFA` },
    { label: "Commandes", value: ordersCount ?? 0 },
    { label: "Clients", value: uniqueCustomers },
    { label: "Produits", value: productsCount ?? 0 },
    { label: "Produits publiés", value: publishedCount ?? 0 },
    { label: "Produits en brouillon", value: draftCount ?? 0 },
  ];

  return (
    <div>
      <h1 className="text-2xl font-medium">Dashboard</h1>
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-card border border-line bg-surface p-6">
            <p className="text-sm text-muted">{s.label}</p>
            <p className="mt-2 text-2xl font-semibold">{s.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

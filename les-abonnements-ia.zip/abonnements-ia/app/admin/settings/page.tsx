import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";
import SettingsForm from "@/components/admin/SettingsForm";

export default async function AdminSettingsPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data } = await supabase.from("settings").select("value").eq("key", "store").single();

  return (
    <div className="max-w-lg">
      <h1 className="text-2xl font-medium">Paramètres de la boutique</h1>
      <div className="mt-8">
        <SettingsForm initial={data?.value ?? { name: "", currency: "FCFA", contact_email: "" }} />
      </div>
    </div>
  );
}

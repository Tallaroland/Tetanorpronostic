import { requireAdmin } from "@/lib/auth";
import { getAdminClient } from "@/lib/supabase/admin";

export default async function AdminCustomersPage() {
  await requireAdmin();
  const supabase = getAdminClient();
  const { data: orders } = await supabase
    .from("orders")
    .select("customer_name, customer_email, total, status, created_at")
    .order("created_at", { ascending: false });

  const byEmail = new Map<
    string,
    { name: string; email: string; ordersCount: number; totalPaid: number; lastOrder: string }
  >();

  for (const o of orders ?? []) {
    const existing = byEmail.get(o.customer_email);
    const paid = o.status === "PAID" ? o.total : 0;
    if (existing) {
      existing.ordersCount += 1;
      existing.totalPaid += paid;
    } else {
      byEmail.set(o.customer_email, {
        name: o.customer_name,
        email: o.customer_email,
        ordersCount: 1,
        totalPaid: paid,
        lastOrder: o.created_at,
      });
    }
  }

  const customers = Array.from(byEmail.values());

  return (
    <div>
      <h1 className="text-2xl font-medium">Clients</h1>

      <div className="mt-8 overflow-x-auto rounded-card border border-line">
        <table className="w-full text-left text-sm">
          <thead className="bg-surface text-muted">
            <tr>
              <th className="px-4 py-3">Nom</th>
              <th className="px-4 py-3">E-mail</th>
              <th className="px-4 py-3">Commandes</th>
              <th className="px-4 py-3">Total payé</th>
              <th className="px-4 py-3">Dernière commande</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-line/60">
            {customers.map((c) => (
              <tr key={c.email}>
                <td className="px-4 py-3">{c.name}</td>
                <td className="px-4 py-3 text-muted">{c.email}</td>
                <td className="px-4 py-3">{c.ordersCount}</td>
                <td className="px-4 py-3">{c.totalPaid.toLocaleString("fr-FR")} FCFA</td>
                <td className="px-4 py-3 text-muted">
                  {new Date(c.lastOrder).toLocaleDateString("fr-FR")}
                </td>
              </tr>
            ))}
            {customers.length === 0 && (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">
                  Aucun client pour le moment.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function ContactPage() {
  return (
    <div className="mx-auto max-w-xl px-5 py-16">
      <h1 className="text-3xl font-medium">Contact</h1>
      <p className="mt-3 text-muted">
        Une question sur un produit ou une commande ? Écrivez-nous, nous répondons sous 24h.
      </p>
      <div className="mt-8 rounded-card border border-line bg-surface p-6 text-sm">
        <p className="text-muted">E-mail</p>
        <p className="mt-1">contact@lesabonnementsia.com</p>
        <p className="mt-4 text-muted">WhatsApp</p>
        <p className="mt-1">+237 6XX XXX XXX</p>
      </div>
    </div>
  );
}

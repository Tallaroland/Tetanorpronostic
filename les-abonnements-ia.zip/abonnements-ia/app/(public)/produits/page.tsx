import { getPublishedProducts, getCategories } from "@/lib/data";
import ProductCard from "@/components/ProductCard";
import SearchBar from "@/components/SearchBar";
import Link from "next/link";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: { q?: string; categorie?: string };
}) {
  const [products, categories] = await Promise.all([
    getPublishedProducts({ search: searchParams.q, categorySlug: searchParams.categorie }),
    getCategories(),
  ]);

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="text-3xl font-medium">Produits</h1>
      <p className="mt-2 text-muted">
        {products.length} produit{products.length > 1 ? "s" : ""} disponible
        {products.length > 1 ? "s" : ""}
      </p>

      <div className="mt-8">
        <SearchBar defaultValue={searchParams.q} />
      </div>

      {categories.length > 0 && (
        <div className="mt-5 flex flex-wrap gap-2">
          <Link
            href="/produits"
            className={`rounded-full border px-4 py-1.5 text-sm ${
              !searchParams.categorie ? "border-gold text-paper" : "border-line text-muted"
            }`}
          >
            Tout
          </Link>
          {categories.map((c) => (
            <Link
              key={c.id}
              href={`/produits?categorie=${c.slug}`}
              className={`rounded-full border px-4 py-1.5 text-sm ${
                searchParams.categorie === c.slug
                  ? "border-gold text-paper"
                  : "border-line text-muted"
              }`}
            >
              {c.name}
            </Link>
          ))}
        </div>
      )}

      {products.length > 0 ? (
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      ) : (
        <p className="mt-16 text-center text-muted">Aucun produit ne correspond à votre recherche.</p>
      )}
    </div>
  );
}

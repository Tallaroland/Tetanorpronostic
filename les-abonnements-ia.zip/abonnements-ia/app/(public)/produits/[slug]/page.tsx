import { notFound } from "next/navigation";
import Image from "next/image";
import { getPublishedProductBySlug } from "@/lib/data";
import AddToCartButton from "@/components/AddToCartButton";
import type { Metadata } from "next";

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const product = await getPublishedProductBySlug(params.slug);
  if (!product) return {};

  const title = product.seo_title || product.name;
  const description = product.seo_description || product.short_description || undefined;

  return {
    title: `${title} — Les Abonnements IA`,
    description,
    alternates: { canonical: `/produits/${product.slug}` },
    openGraph: {
      title,
      description,
      images: product.image_url ? [product.image_url] : undefined,
      type: "website",
    },
  };
}

export default async function ProductDetailPage({ params }: { params: { slug: string } }) {
  const product = await getPublishedProductBySlug(params.slug);
  if (!product) notFound();

  const hasPromo = !!product.old_price && product.old_price > product.price;
  const discount = hasPromo
    ? Math.round((1 - product.price / (product.old_price as number)) * 100)
    : 0;
  const gallery = [product.image_url, ...(product.gallery_urls ?? [])].filter(Boolean) as string[];

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <div className="grid gap-12 md:grid-cols-2">
        <div>
          <div className="relative aspect-[4/3] overflow-hidden rounded-card border border-line bg-surface">
            {gallery[0] ? (
              <Image src={gallery[0]} alt={product.name} fill className="object-cover" priority />
            ) : (
              <div className="flex h-full items-center justify-center text-muted">Aperçu</div>
            )}
          </div>
          {gallery.length > 1 && (
            <div className="mt-3 grid grid-cols-4 gap-3">
              {gallery.slice(1).map((url, i) => (
                <div key={i} className="relative aspect-square overflow-hidden rounded-lg border border-line">
                  <Image src={url} alt={`${product.name} ${i + 2}`} fill className="object-cover" />
                </div>
              ))}
            </div>
          )}
        </div>

        <div>
          {product.categories?.name && (
            <p className="text-sm text-teal">{product.categories.name}</p>
          )}
          <h1 className="mt-2 text-3xl font-medium leading-tight">{product.name}</h1>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="text-2xl font-semibold">{product.price.toLocaleString("fr-FR")} FCFA</span>
            {hasPromo && (
              <>
                <span className="text-muted line-through">
                  {product.old_price?.toLocaleString("fr-FR")} FCFA
                </span>
                <span className="rounded-full bg-gold px-2.5 py-1 text-xs font-semibold text-ink">
                  -{discount}%
                </span>
              </>
            )}
          </div>

          {product.short_description && (
            <p className="mt-5 text-muted">{product.short_description}</p>
          )}

          <div className="mt-7">
            <AddToCartButton product={product} />
          </div>

          <ul className="mt-6 space-y-2 text-sm text-muted">
            <li>⚡ Accès instantané après paiement</li>
            <li>🔒 Paiement sécurisé</li>
            <li>💬 Support client</li>
          </ul>

          {product.benefits?.length > 0 && (
            <div className="mt-9">
              <h2 className="text-lg font-medium">Avantages</h2>
              <ul className="mt-3 space-y-2">
                {product.benefits.map((b, i) => (
                  <li key={i} className="flex gap-2 text-sm text-paper">
                    <span className="text-teal">✓</span>
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {product.features?.length > 0 && (
            <div className="mt-9">
              <h2 className="text-lg font-medium">Caractéristiques</h2>
              <dl className="mt-3 divide-y divide-line/60 text-sm">
                {product.features.map((f, i) => (
                  <div key={i} className="flex justify-between py-2">
                    <dt className="text-muted">{f.label}</dt>
                    <dd className="text-paper">{f.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </div>
      </div>

      {product.description && (
        <div className="mt-16 max-w-3xl">
          <h2 className="text-xl font-medium">Description</h2>
          <p className="mt-4 whitespace-pre-line text-muted">{product.description}</p>
        </div>
      )}
    </div>
  );
}

import Link from "next/link";
import { getAdminClient } from "@/lib/supabase/admin";
import { notFound } from "next/navigation";

export default async function OrderConfirmationPage({ params }: { params: { id: string } }) {
  const supabase = getAdminClient();
  const { data: order } = await supabase
    .from("orders")
    .select("id, status, total, customer_name, customer_email, created_at")
    .eq("id", params.id)
    .single();

  if (!order) notFound();

  const isPaid = order.status === "PAID";

  return (
    <div className="mx-auto max-w-xl px-5 py-20 text-center">
      <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-surface text-2xl">
        {isPaid ? "✅" : "⏳"}
      </div>
      <h1 className="text-2xl font-medium">
        {isPaid ? "Paiement confirmé" : "Commande enregistrée"}
      </h1>
      <p className="mt-3 text-muted">
        {isPaid
          ? "Votre accès a été envoyé à " + order.customer_email + "."
          : "Nous finalisons la confirmation de votre paiement. Vous recevrez vos accès par e-mail à " +
            order.customer_email +
            " dès validation."}
      </p>
      <p className="mt-6 text-sm text-muted">
        Référence de commande : <span className="text-paper">{order.id}</span>
      </p>
      <Link href="/produits" className="mt-10 inline-block text-sm text-teal hover:underline">
        Retour à la boutique
      </Link>
    </div>
  );
}

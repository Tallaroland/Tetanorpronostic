import Link from "next/link";
import { getCategories } from "@/lib/data";

export default async function CategoriesPage() {
  const categories = await getCategories();

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <h1 className="text-3xl font-medium">Catégories</h1>
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
        {categories.map((c) => (
          <Link
            key={c.id}
            href={`/produits?categorie=${c.slug}`}
            className="rounded-card border border-line bg-surface p-6 text-center transition-colors hover:border-gold"
          >
            <span className="font-medium">{c.name}</span>
          </Link>
        ))}
        {categories.length === 0 && (
          <p className="col-span-full text-muted">Aucune catégorie pour le moment.</p>
        )}
      </div>
    </div>
  );
}

"use client";

import Link from "next/link";
import Image from "next/image";
import { useCart } from "@/contexts/CartContext";

export default function CartPage() {
  const { items, removeItem, subtotal } = useCart();

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-5 py-20 text-center">
        <h1 className="text-2xl font-medium">Votre panier est vide</h1>
        <p className="mt-3 text-muted">Parcourez nos produits et ajoutez-en à votre panier.</p>
        <Link
          href="/produits"
          className="mt-8 inline-block rounded-card bg-gold px-6 py-3 text-sm font-semibold text-ink"
        >
          Voir les produits
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-5 py-12">
      <h1 className="text-3xl font-medium">Votre panier</h1>

      <div className="mt-8 divide-y divide-line/60 border-y border-line/60">
        {items.map((item) => (
          <div key={item.productId} className="flex items-center gap-4 py-5">
            <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-lg border border-line bg-surface">
              {item.image_url && (
                <Image src={item.image_url} alt={item.name} fill className="object-cover" />
              )}
            </div>
            <div className="flex-1">
              <Link href={`/produits/${item.slug}`} className="font-medium hover:text-teal">
                {item.name}
              </Link>
              <p className="text-sm text-muted">Produit digital · quantité 1</p>
            </div>
            <p className="font-medium">{(item.price * item.quantity).toLocaleString("fr-FR")} FCFA</p>
            <button
              onClick={() => removeItem(item.productId)}
              aria-label={`Retirer ${item.name}`}
              className="text-muted hover:text-paper"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <div className="mt-8 flex items-center justify-between">
        <span className="text-muted">Sous-total</span>
        <span className="text-xl font-semibold">{subtotal.toLocaleString("fr-FR")} FCFA</span>
      </div>

      <Link
        href="/checkout"
        className="mt-8 block rounded-card bg-gold py-3.5 text-center text-sm font-semibold text-ink"
      >
        Passer à la commande
      </Link>
    </div>
  );
}

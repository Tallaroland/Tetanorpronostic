"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useCart } from "@/contexts/CartContext";

export default function CheckoutPage() {
  const { items, subtotal, clear } = useCart();
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "" });

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customer: form,
          items: items.map((i) => ({ productId: i.productId, quantity: i.quantity })),
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Une erreur est survenue.");

      clear();
      // En production: data.paymentUrl redirige vers l'agrégateur Mobile Money.
      router.push(`/commande/${data.orderId}`);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-5 py-20 text-center text-muted">
        Votre panier est vide.
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-5 py-12">
      <h1 className="text-3xl font-medium">Finaliser la commande</h1>

      <div className="mt-8 rounded-card border border-line bg-surface p-5">
        {items.map((i) => (
          <div key={i.productId} className="flex justify-between py-1.5 text-sm">
            <span>{i.name}</span>
            <span>{(i.price * i.quantity).toLocaleString("fr-FR")} FCFA</span>
          </div>
        ))}
        <div className="mt-3 flex justify-between border-t border-line/60 pt-3 font-medium">
          <span>Total</span>
          <span>{subtotal.toLocaleString("fr-FR")} FCFA</span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="mt-8 space-y-4">
        <div>
          <label className="mb-1.5 block text-sm text-muted">Nom complet</label>
          <input
            required
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            className="w-full rounded-card border border-line bg-surface px-4 py-3 text-sm focus:border-teal"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm text-muted">Adresse e-mail</label>
          <input
            required
            type="email"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full rounded-card border border-line bg-surface px-4 py-3 text-sm focus:border-teal"
            placeholder="Pour recevoir votre accès après paiement"
          />
        </div>
        <div>
          <label className="mb-1.5 block text-sm text-muted">Numéro Mobile Money</label>
          <input
            required
            value={form.phone}
            onChange={(e) => setForm({ ...form, phone: e.target.value })}
            className="w-full rounded-card border border-line bg-surface px-4 py-3 text-sm focus:border-teal"
            placeholder="+237 6XX XXX XXX"
          />
        </div>

        {error && <p className="text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-card bg-gold py-3.5 text-sm font-semibold text-ink disabled:opacity-60"
        >
          {loading ? "Traitement…" : "Payer maintenant"}
        </button>
        <p className="text-center text-xs text-muted">Paiement sécurisé · Accès instantané après confirmation</p>
      </form>
    </div>
  );
}

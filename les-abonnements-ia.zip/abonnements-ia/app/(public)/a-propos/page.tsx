export default function AboutPage() {
  return (
    <div className="mx-auto max-w-2xl px-5 py-16">
      <h1 className="text-3xl font-medium">À propos</h1>
      <p className="mt-4 text-muted">
        Les Abonnements IA propose des produits numériques — formations, e-books,
        templates et outils — pensés pour aider les créateurs et entrepreneurs
        camerounais et africains à avancer plus vite sur leurs projets.
      </p>
      <p className="mt-4 text-muted">
        Chaque produit est livré instantanément après paiement, avec un accès
        sécurisé et un support client réactif.
      </p>
    </div>
  );
}

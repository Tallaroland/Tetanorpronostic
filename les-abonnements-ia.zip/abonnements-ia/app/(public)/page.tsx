import Link from "next/link";
import { getPublishedProducts, getCategories } from "@/lib/data";
import ProductCard from "@/components/ProductCard";

export default async function HomePage() {
  const [products, categories] = await Promise.all([
    getPublishedProducts(),
    getCategories(),
  ]);
  const featured = products.slice(0, 6);

  return (
    <div>
      {/* HERO — asymétrique, empilement de "cartes produit" légèrement inclinées */}
      <section className="mx-auto max-w-6xl px-5 pb-16 pt-14 md:pt-24">
        <div className="grid items-center gap-12 md:grid-cols-[1.1fr_0.9fr]">
          <div>
            <p className="mb-5 text-sm text-teal">Boutique numérique · Cameroun & Afrique</p>
            <h1 className="max-w-xl text-4xl font-medium leading-[1.08] tracking-tight md:text-5xl">
              Des produits digitaux pour développer vos projets
            </h1>
            <p className="mt-6 max-w-md text-base text-muted">
              Découvrez nos produits numériques, formations, ressources et outils
              disponibles instantanément.
            </p>
            <div className="mt-9 flex flex-wrap gap-4">
              <Link
                href="/produits"
                className="rounded-card bg-gold px-6 py-3 text-sm font-semibold text-ink transition-transform hover:scale-[1.02]"
              >
                Découvrir les produits
              </Link>
              <Link
                href="/categories"
                className="rounded-card border border-line px-6 py-3 text-sm text-paper transition-colors hover:border-teal"
              >
                Parcourir les catégories
              </Link>
            </div>
          </div>

          <div className="relative hidden h-80 md:block">
            {featured.slice(0, 3).map((p, i) => (
              <div
                key={p.id}
                className="absolute w-64 rounded-card border border-line bg-surface p-4 shadow-xl"
                style={{
                  top: `${i * 46}px`,
                  left: `${i * 34}px`,
                  transform: `rotate(${(i - 1) * 4}deg)`,
                  zIndex: 3 - i,
                }}
              >
                <div className="mb-3 aspect-[4/3] rounded-lg bg-surface2" />
                <p className="truncate text-sm font-medium text-paper">{p.name}</p>
                <p className="text-xs text-muted">{p.price.toLocaleString("fr-FR")} FCFA</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRODUITS EN AVANT */}
      {featured.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 pb-20">
          <div className="mb-8 flex items-end justify-between">
            <h2 className="text-2xl font-medium">Produits récents</h2>
            <Link href="/produits" className="text-sm text-teal hover:underline">
              Voir tout
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}

      {/* CATÉGORIES */}
      {categories.length > 0 && (
        <section className="mx-auto max-w-6xl px-5 pb-24">
          <h2 className="mb-8 text-2xl font-medium">Catégories</h2>
          <div className="flex flex-wrap gap-3">
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/categories/${c.slug}`}
                className="rounded-full border border-line px-4 py-2 text-sm text-muted transition-colors hover:border-gold hover:text-paper"
              >
                {c.name}
              </Link>
            ))}
          </div>
        </section>
      )}

      {featured.length === 0 && (
        <section className="mx-auto max-w-6xl px-5 pb-24 text-center text-muted">
          <p>Aucun produit publié pour le moment. Revenez bientôt.</p>
        </section>
      )}
    </div>
  );
}

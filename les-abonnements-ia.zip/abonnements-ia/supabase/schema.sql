-- ============================================================
-- LES ABONNEMENTS IA — schéma de base de données (Supabase/Postgres)
-- À exécuter dans Supabase > SQL Editor
-- ============================================================

create extension if not exists "uuid-ossp";

-- ---------- ENUMS ----------
create type user_role as enum ('USER', 'ADMIN');
create type product_status as enum ('DRAFT', 'PUBLISHED');
create type product_type as enum ('DOWNLOAD', 'ACCESS', 'SUBSCRIPTION', 'OTHER');
create type order_status as enum ('PENDING', 'PAID', 'FAILED', 'CANCELLED');
create type subscription_status as enum ('ACTIVE', 'EXPIRED', 'CANCELLED');

-- ---------- PROFILES (rôle séparé de auth.users) ----------
-- Un utilisateur ne peut jamais modifier son propre rôle : la colonne role
-- n'est modifiable que par le service_role (back-office), jamais via le client.
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  role user_role not null default 'USER',
  created_at timestamptz not null default now()
);

-- ---------- CATEGORIES ----------
create table categories (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  created_at timestamptz not null default now()
);

-- ---------- PRODUCTS ----------
create table products (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  short_description text,
  description text,
  price integer not null,               -- en FCFA (entier, pas de centimes)
  old_price integer,
  category_id uuid references categories(id) on delete set null,
  image_url text,
  gallery_urls text[] default '{}',
  benefits text[] default '{}',
  features jsonb default '[]',
  product_type product_type not null default 'DOWNLOAD',
  delivery_url text,                    -- fichier/lien protégé (jamais exposé publiquement tel quel)
  status product_status not null default 'DRAFT',
  seo_title text,
  seo_description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_products_status on products(status);
create index idx_products_category on products(category_id);

-- ---------- ORDERS ----------
create table orders (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete set null,
  customer_email text not null,
  customer_name text,
  total integer not null,
  status order_status not null default 'PENDING',
  payment_reference text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- ORDER ITEMS ----------
create table order_items (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid not null references products(id),
  product_name text not null,
  unit_price integer not null,
  quantity integer not null default 1
);

-- ---------- PAYMENTS ----------
create table payments (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references orders(id) on delete cascade,
  provider text not null,
  provider_reference text,
  amount integer not null,
  status order_status not null default 'PENDING',
  raw_payload jsonb,
  created_at timestamptz not null default now()
);

-- ---------- DIGITAL DELIVERIES ----------
-- Ne contient jamais l'URL publique brute : delivery_token sert à générer
-- un lien signé/à durée limitée côté API (/api/download/[token]).
create table digital_deliveries (
  id uuid primary key default uuid_generate_v4(),
  order_item_id uuid not null references order_items(id) on delete cascade,
  delivery_token text not null unique default encode(gen_random_bytes(24), 'hex'),
  expires_at timestamptz,
  downloads_count integer not null default 0,
  max_downloads integer default 5,
  created_at timestamptz not null default now()
);

-- ---------- SUBSCRIPTIONS ----------
create table subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete set null,
  product_id uuid not null references products(id),
  order_id uuid references orders(id),
  start_date timestamptz not null default now(),
  end_date timestamptz,
  status subscription_status not null default 'ACTIVE'
);

-- ---------- SETTINGS ----------
create table settings (
  key text primary key,
  value jsonb not null
);

insert into settings (key, value) values
  ('store', '{"name":"Les Abonnements IA","currency":"FCFA","contact_email":"contact@lesabonnementsia.com"}');

-- ---------- AUTO-CRÉATION DU PROFIL À L'INSCRIPTION ----------
-- Chaque nouvel utilisateur Supabase Auth reçoit automatiquement une ligne
-- "profiles" avec le rôle USER. Le rôle ADMIN ne peut être attribué qu'en
-- SQL Editor (voir README), jamais par une action du client.
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'USER');
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- ROW LEVEL SECURITY
-- Principe: tout est vérifié côté serveur. Les policies ci-dessous
-- sont une deuxième ligne de défense en plus du contrôle applicatif
-- (middleware + vérification du rôle dans les routes API).
-- ============================================================

alter table profiles enable row level security;
alter table categories enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table payments enable row level security;
alter table digital_deliveries enable row level security;
alter table subscriptions enable row level security;
alter table settings enable row level security;

-- Lecture publique des catégories et des produits PUBLIÉS uniquement
create policy "public read categories" on categories for select using (true);
create policy "public read published products" on products for select using (status = 'PUBLISHED');

-- Un utilisateur voit seulement son propre profil
create policy "user reads own profile" on profiles for select using (auth.uid() = id);

-- Un utilisateur voit ses propres commandes
create policy "user reads own orders" on orders for select using (auth.uid() = user_id);
create policy "user reads own order_items" on order_items for select using (
  exists (select 1 from orders o where o.id = order_items.order_id and o.user_id = auth.uid())
);
create policy "user reads own subscriptions" on subscriptions for select using (auth.uid() = user_id);

-- Aucune policy INSERT/UPDATE/DELETE côté client (anon/authenticated) sur products,
-- categories, orders, payments, digital_deliveries, settings, ou le rôle dans profiles :
-- toute écriture passe exclusivement par les routes API serveur, qui utilisent la
-- clé service_role (laquelle bypass RLS et n'est jamais exposée au navigateur).
-- C'est ce qui garantit qu'un client ne peut jamais s'auto-promouvoir ADMIN.

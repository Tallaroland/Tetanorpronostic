import { createBrowserClient } from "@supabase/ssr";

/**
 * Client Supabase pour le navigateur.
 * N'utilise QUE la clé anonyme (publique) — jamais la service_role key.
 * Les droits réels sont appliqués par les policies RLS + les routes API serveur.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

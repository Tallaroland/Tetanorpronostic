import "server-only";
import { createClient as createSupabaseClient } from "@supabase/supabase-js";

/**
 * Client Supabase "admin", avec la clé service_role.
 *
 * ⚠️ IMPORTANT :
 * - Le paquet "server-only" fait planter le build si ce fichier est jamais
 *   importé depuis un composant client → protection anti-fuite de la clé.
 * - N'appeler getAdminClient() que depuis des Route Handlers (app/api/**)
 *   ou des Server Actions, APRÈS avoir vérifié requireAdmin() (voir lib/auth.ts).
 * - Cette clé bypass toutes les policies RLS : elle ne doit jamais
 *   transiter par le navigateur ni être loguée.
 */
export function getAdminClient() {
  return createSupabaseClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    {
      auth: { autoRefreshToken: false, persistSession: false },
    }
  );
}

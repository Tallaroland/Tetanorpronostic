export type ProductType = "DOWNLOAD" | "ACCESS" | "SUBSCRIPTION" | "OTHER";
export type ProductStatus = "DRAFT" | "PUBLISHED";

export type Category = {
  id: string;
  name: string;
  slug: string;
};

export type Product = {
  id: string;
  name: string;
  slug: string;
  short_description: string | null;
  description: string | null;
  price: number;
  old_price: number | null;
  category_id: string | null;
  categories?: Category | null;
  image_url: string | null;
  gallery_urls: string[];
  benefits: string[];
  features: { label: string; value: string }[];
  product_type: ProductType;
  delivery_url: string | null;
  status: ProductStatus;
  seo_title: string | null;
  seo_description: string | null;
  created_at: string;
  updated_at: string;
};

export type CartItem = {
  productId: string;
  name: string;
  slug: string;
  price: number;
  image_url: string | null;
  quantity: number;
};

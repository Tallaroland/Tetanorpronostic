import { createClient } from "@/lib/supabase/server";
import type { Product, Category } from "@/lib/types";

/**
 * Toutes les fonctions ci-dessous utilisent le client serveur avec la clé
 * anonyme : la policy RLS "public read published products" garantit que
 * seuls les produits status = 'PUBLISHED' sont jamais renvoyés ici, même
 * en cas d'erreur de filtrage applicatif.
 */

export async function getPublishedProducts(opts?: {
  categorySlug?: string;
  search?: string;
}): Promise<Product[]> {
  const supabase = createClient();
  let query = supabase
    .from("products")
    .select("*, categories(id, name, slug)")
    .eq("status", "PUBLISHED")
    .order("created_at", { ascending: false });

  if (opts?.categorySlug) {
    const { data: cat } = await supabase
      .from("categories")
      .select("id")
      .eq("slug", opts.categorySlug)
      .single();
    if (cat) query = query.eq("category_id", cat.id);
  }

  if (opts?.search) {
    query = query.or(
      `name.ilike.%${opts.search}%,description.ilike.%${opts.search}%,short_description.ilike.%${opts.search}%`
    );
  }

  const { data, error } = await query;
  if (error) {
    console.error("getPublishedProducts:", error.message);
    return [];
  }
  return (data as Product[]) ?? [];
}

export async function getPublishedProductBySlug(slug: string): Promise<Product | null> {
  const supabase = createClient();
  const { data, error } = await supabase
    .from("products")
    .select("*, categories(id, name, slug)")
    .eq("status", "PUBLISHED")
    .eq("slug", slug)
    .single();

  if (error) return null;
  return data as Product;
}

export async function getCategories(): Promise<Category[]> {
  const supabase = createClient();
  const { data } = await supabase.from("categories").select("*").order("name");
  return (data as Category[]) ?? [];
}

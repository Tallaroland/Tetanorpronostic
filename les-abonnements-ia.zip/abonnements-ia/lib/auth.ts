import "server-only";
import { createClient } from "@/lib/supabase/server";

export type Profile = {
  id: string;
  email: string;
  full_name: string | null;
  role: "USER" | "ADMIN";
};

/**
 * Retourne l'utilisateur connecté et son profil (avec rôle), ou null.
 * Le rôle est lu depuis la table "profiles" en base — jamais depuis
 * un champ modifiable côté client (localStorage, cookie non signé, etc.).
 */
export async function getCurrentProfile(): Promise<Profile | null> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, email, full_name, role")
    .eq("id", user.id)
    .single();

  return (profile as Profile) ?? null;
}

/**
 * Garde d'accès pour les Route Handlers admin (app/api/admin/**).
 * Renvoie le profil si ADMIN, sinon lève une erreur — à utiliser en tout début
 * de chaque handler avant toute lecture/écriture sensible.
 */
export async function requireAdmin(): Promise<Profile> {
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== "ADMIN") {
    throw new Error("FORBIDDEN");
  }
  return profile;
}

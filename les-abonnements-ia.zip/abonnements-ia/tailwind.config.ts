import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./contexts/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0E0F1F",
        surface: "#161832",
        surface2: "#1F2242",
        line: "#2B2E54",
        paper: "#F3F1EC",
        gold: {
          DEFAULT: "#F2B441",
          soft: "#F7CC77",
        },
        teal: {
          DEFAULT: "#2FD3B8",
          dim: "#1C7C6C",
        },
        muted: "#9498C0",
      },
      fontFamily: {
        display: ["var(--font-space-grotesk)", "sans-serif"],
        body: ["var(--font-inter)", "sans-serif"],
      },
      borderRadius: {
        card: "14px",
      },
    },
  },
  plugins: [],
};

export default config;
